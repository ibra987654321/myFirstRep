$(function () {
    var carousel = $("#showcase").waterwheelCarousel({
        flankingItems: 3,
        movingToCenter: function ($item) {
          $('#callback-output').prepend('movingToCenter: ' + $item.attr('id') + '<br/>');
        },
        movedToCenter: function ($item) {
          $('#callback-output').prepend('movedToCenter: ' + $item.attr('id') + '<br/>');
        },
        movingFromCenter: function ($item) {
          $('#callback-output').prepend('movingFromCenter: ' + $item.attr('id') + '<br/>');
        }
      });

      $('.snav-left').bind('click', function () {
        carousel.prev();
        return false
      });

      $('.snav-right').bind('click', function () {
        carousel.next();
        return false;
      });

      $('#reload').bind('click', function () {
        newOptions = eval("(" + $('#newoptions').val() + ")");
        carousel.reload(newOptions);
        return false;
      });

});